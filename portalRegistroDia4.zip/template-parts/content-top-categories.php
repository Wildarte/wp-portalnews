<section class="container select_category_top">
    <article class="card_select_category_top">
        <span class="top_category">
            <a href="">
                Sports
            </a>
        </span>
        <h3 class="card_category_title">
            <a href="">
                Incongruous Jeepers Jellyfish One Far Well Known
            </a>
        </h3>
    </article>
    <article class="card_select_category_top">
        <span class="top_category">
            <a href="">
                Technology
            </a>
        </span>
        <h3 class="card_category_title">
            <a href="">
                Fat Bias Starts Early and at Bias Starts Early and
            </a>
        </h3>
    </article>
    <article class="card_select_category_top">
        <span class="top_category">
            <a href="">
                Sports
            </a>
        </span>
        <h3 class="card_category_title">
            <a href="">
                Lorem ipsum, dolor sit amet consectetur adipisicing!
            </a>
        </h3>
    </article>
    <article class="card_select_category_top">
        <span class="top_category">
            <a href="">
                Sports
            </a>
        </span>
        <h3 class="card_category_title">
            <a href="">
                Incongruous Jeepers Jellyfish One Far Well Known
            </a>
        </h3>
    </article>
</section>