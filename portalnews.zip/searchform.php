<form role="search" method="get" id="searchform" class="searchform" action="<? home_url() ?>">
        
    <input type="text" value="" name="s" id="s">
    <input type="submit" id="searchsubmit" value="Search">

</form>