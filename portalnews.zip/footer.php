<footer class="footer">
        <div class="container content_footer d-flex">
          <div class="f-25 footer_about footer_col">
            <h3>Sobre</h3>
            <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Aspernatur iusto tempora ad magni dicta expedita quis perspiciatis pariatur, voluptate soluta voluptatem! Officiis, iusto?</p>
          </div>
          <div class="f-25 footer_col">
            <h3>News</h3>

            <div class="footer_list_post">
              <a href="">
                <h4>Incongruous Jeepers Jellyfish One Far Well Known</h4>
              </a>

              <a href="">
                <h4>Timmediately Quail Was Inverse Much So Remade Dimly Salmon</h4>
              </a>
            </div>
          </div>
          <div class="f-25 footer_col">
            <h3>News</h3>

            <div class="footer_list_post">
              <a href="">
                <h4>Incongruous Jeepers Jellyfish One Far Well Known</h4>
              </a>

              <a href="">
                <h4>Timmediately Quail Was Inverse Much So Remade Dimly Salmon</h4>
              </a>
            </div>
          </div>
          <div class="f-25 footer_col">
            <h3>News</h3>

            <div class="footer_list_post">
              <a href="">
                <h4>Incongruous Jeepers Jellyfish One Far Well Known</h4>
              </a>

              <a href="">
                <h4>Timmediately Quail Was Inverse Much So Remade Dimly Salmon</h4>
              </a>
            </div>
          </div>
          </div>
        </div>
        <div class="bottom_footer">
          <div class="container">
            <p>© Copyright 2022 - My Blog. All Rights Reserved</p>
          </div>
          
        </div>
    </footer>
    <script src="assets/js/script.js"></script>
    <?php wp_footer() ?>
</body>
</html>