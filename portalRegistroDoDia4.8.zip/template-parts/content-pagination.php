<div class="control_posts_pagination container">
    <?php

    the_posts_pagination( 'mid_size=3' );

    ?>
</div>