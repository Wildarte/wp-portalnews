<?php get_header() ?>

<main>

    <section class="page_author">
        <div class="container d-flex">
            <div class="f-70 page_author_left">
                <div class="info_author_post d-flex">
                    <div class="thumb_author">
                        <img src="https://tothetheme.com/newsmonster/wp-content/uploads/2022/02/avatar_user_2_1645079868-200x200.jpg" alt="">
                    </div>
                    <div class="info_author">
                        <h3>Jeane Doerman</h3>
                        <p>Within spread beside the ouch sulky and this wonderfully and as the well and where supply much hyena so tolerantly recast hawk darn woodpecker less more so.</p>
                    </div>
                </div>

                <div class="list_card_post_hor">
                    <article class="card_post_hor">
                        <div class="info_card_post_hor d-flex">
                            <div class="date_card_post_hor"><small><span>01 de maio de 2019</span>  <strong>Política</strong></small></div>

                            <div class=""></div>
                        </div>

                        <div class="title_card_post_hor">
                            <h2><a href="">Incongruous Jeepers Jellyfish One Far Well Known</a> </h2>
                        </div>

                        <div class="content_card_post_hor d-flex">
                            <div class="thumb_card_post_hor">
                                <a href="">
                                    <img src="https://tothetheme.com/newsmonster/wp-content/uploads/2016/12/demo-image11-250x150.jpg" alt="">
                                </a>
                                
                            </div>

                            <div class="resume_card_post_hor">
                                <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Doloribus, veritatis beatae animi voluptatem minus facilis sed ratione facere voluptate, consectetur neque. Velit quidem eos voluptate assumenda nesciunt nulla accusamus aliquid eius odio non, labore delectus repellat error exercitationem temporibus doloremque?</p>
                            </div>

                        </div>
                    </article>

                    <article class="card_post_hor">
                        <div class="info_card_post_hor d-flex">
                            <div class="date_card_post_hor"><small><span>01 de maio de 2019</span>  <strong>Política</strong></small></div>

                            <div class=""></div>
                        </div>

                        <div class="title_card_post_hor">
                            <h2><a href="">Incongruous Jeepers Jellyfish One Far Well Known</a> </h2>
                        </div>

                        <div class="content_card_post_hor d-flex">
                            <div class="thumb_card_post_hor">
                                <a href="">
                                    <img src="https://tothetheme.com/newsmonster/wp-content/uploads/2016/12/demo-image11-250x150.jpg" alt="">
                                </a>
                                
                            </div>

                            <div class="resume_card_post_hor">
                                <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Doloribus, veritatis beatae animi voluptatem minus facilis sed ratione facere voluptate, consectetur neque. Velit quidem eos voluptate assumenda nesciunt nulla accusamus aliquid eius odio non, labore delectus repellat error exercitationem temporibus doloremque?</p>
                            </div>

                        </div>
                    </article>

                    <article class="card_post_hor">
                        <div class="info_card_post_hor d-flex">
                            <div class="date_card_post_hor"><small><span>01 de maio de 2019</span>  <strong>Política</strong></small></div>

                            <div class=""></div>
                        </div>

                        <div class="title_card_post_hor">
                            <h2><a href="">Incongruous Jeepers Jellyfish One Far Well Known</a> </h2>
                        </div>

                        <div class="content_card_post_hor d-flex">
                            <div class="thumb_card_post_hor">
                                <a href="">
                                    <img src="https://tothetheme.com/newsmonster/wp-content/uploads/2016/12/demo-image11-250x150.jpg" alt="">
                                </a>
                                
                            </div>

                            <div class="resume_card_post_hor">
                                <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Doloribus, veritatis beatae animi voluptatem minus facilis sed ratione facere voluptate, consectetur neque. Velit quidem eos voluptate assumenda nesciunt nulla accusamus aliquid eius odio non, labore delectus repellat error exercitationem temporibus doloremque?</p>
                            </div>

                        </div>
                    </article>

                    <article class="card_post_hor">
                        <div class="info_card_post_hor d-flex">
                            <div class="date_card_post_hor"><small><span>01 de maio de 2019</span>  <strong>Política</strong></small></div>

                            <div class=""></div>
                        </div>

                        <div class="title_card_post_hor">
                            <h2><a href="">Incongruous Jeepers Jellyfish One Far Well Known</a> </h2>
                        </div>

                        <div class="content_card_post_hor d-flex">
                            <div class="thumb_card_post_hor">
                                <a href="">
                                    <img src="https://tothetheme.com/newsmonster/wp-content/uploads/2016/12/demo-image11-250x150.jpg" alt="">
                                </a>
                                
                            </div>

                            <div class="resume_card_post_hor">
                                <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Doloribus, veritatis beatae animi voluptatem minus facilis sed ratione facere voluptate, consectetur neque. Velit quidem eos voluptate assumenda nesciunt nulla accusamus aliquid eius odio non, labore delectus repellat error exercitationem temporibus doloremque?</p>
                            </div>

                        </div>
                    </article>

                    
                </div>
            </div>
            

            <aside class="f-30 sidebar_post">
                <?php include('sidebar.php') ?>
            </aside>
        </div>
    </section>

</main>

<?php get_footer() ?>